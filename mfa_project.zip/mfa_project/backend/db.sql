create database fma_project;

use fma_project;

create table usuarios (
	id int auto_increment primary key,
    nome varchar(100) not null,
    email varchar(100) not null unique,
    senha varchar(100) not null
);


INSERT INTO usuarios (nome, email, senha, tipo)
VALUES ('Administrador', 'admin@local', '$2a$10$zyb...replace_with_hash', 'admin');



ALTER TABLE usuarios
  MODIFY senha VARCHAR(255) NOT NULL,
  ADD COLUMN tipo ENUM('admin','usuario') DEFAULT 'usuario',
  ADD COLUMN criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP;

INSERT INTO usuarios (nome, email, senha, tipo)
VALUES ('Administrador', 'admin@local', 'admin123', 'admin');



CREATE TABLE IF NOT EXISTS cursos (
  id INT AUTO_INCREMENT PRIMARY KEY,
  titulo VARCHAR(200) NOT NULL,
  descricao TEXT,
  duracao VARCHAR(50),
  imagem_url TEXT,               
  video_url VARCHAR(2048),
  criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);


select * from usuarios

