// backend/src/server.js
const express = require('express');
const cors = require('cors');
const mysql = require('mysql2');
const fs = require('fs');
const path = require('path');

const app = express();
app.use(cors());
app.use(express.json({ limit: '10mb' })); // limite geral de payload

const PORT = process.env.PORT || 3001;

// --- MySQL connection
const connection = mysql.createConnection({
  host: 'localhost',
  user: 'root',
  password: 'Root', // ajuste se necessário
  database: 'fma_project'
});

connection.connect(err => {
  if (err) {
    console.error('Erro ao conectar ao MySQL:', err.message);
  } else {
    console.log('Mysql conectado');
  }
});

// --- helper: query promise
function queryAsync(sql, params = []) {
  return new Promise((resolve, reject) => {
    connection.query(sql, params, (err, results) => {
      if (err) return reject(err);
      resolve(results);
    });
  });
}

// ensure uploads folder and serve it
const UPLOAD_DIR = path.join(__dirname, '..', 'uploads');
if (!fs.existsSync(UPLOAD_DIR)) fs.mkdirSync(UPLOAD_DIR, { recursive: true });
app.use('/uploads', express.static(UPLOAD_DIR));

// helper: save data URI to file, returns relative path (e.g., /uploads/name.jpg)
function saveDataUriToFile(dataUri) {
  const match = dataUri.match(/^data:(image\/[a-zA-Z0-9.+-]+);base64,(.+)$/);
  if (!match) return { error: 'Invalid data URI or unsupported format.' };

  const mime = match[1];
  const base64 = match[2];
  const ext = mime.split('/')[1].split('+')[0];

  const buffer = Buffer.from(base64, 'base64');

  // check size (limit e.g., 4 MB)
  const MAX_BYTES = 4 * 1024 * 1024;
  if (buffer.length > MAX_BYTES) {
    return { error: `Imagem muito grande (${Math.round(buffer.length/1024)} KB). Limite ${MAX_BYTES/1024} KB.` };
  }

  const name = `img_${Date.now()}_${Math.floor(Math.random()*9000)+1000}.${ext}`;
  const filepath = path.join(UPLOAD_DIR, name);

  try {
    fs.writeFileSync(filepath, buffer);
  } catch (err) {
    console.error('Erro ao escrever upload:', err);
    return { error: 'Erro ao gravar arquivo no servidor.' };
  }

  const relative = `/uploads/${name}`;
  return { path: relative };
}

// ===================== middleware isAdmin =====================
async function isAdmin(req, res, next) {
  try {
    const userIdRaw = req.headers['x-user-id'];
    const userId = parseInt(userIdRaw, 10);
    if (!userId) return res.status(401).json({ success: false, message: 'Usuário não autenticado.' });

    const rows = await queryAsync('SELECT tipo FROM usuarios WHERE id = ?', [userId]);
    if (!rows || rows.length === 0) return res.status(401).json({ success: false, message: 'Usuário não encontrado.' });

    if (rows[0].tipo !== 'admin') return res.status(403).json({ success: false, message: 'Acesso negado.' });

    req.adminId = userId;
    next();
  } catch (err) {
    console.error('isAdmin error:', err);
    res.status(500).json({ success: false, message: 'Erro no servidor.' });
  }
}

// ===================== ROTAS =====================

// listar cursos (público)
app.get('/courses', async (req, res) => {
  try {
    const rows = await queryAsync('SELECT id, titulo, descricao, duracao, imagem_url, video_url, criado_em FROM cursos ORDER BY id DESC');
    res.json({ success: true, data: rows });
  } catch (err) {
    console.error('GET /courses error:', err);
    res.status(500).json({ success: false, message: 'Erro ao buscar cursos.' });
  }
});

// criar curso (APENAS ADMIN)
app.post('/admin/courses', isAdmin, async (req, res) => {
  try {
    let { titulo, descricao = '', duracao = '', imagem_url = '', video_url } = req.body;
    titulo = (titulo || '').trim();
    video_url = (video_url || '').trim();

    if (!titulo || !video_url) return res.status(400).json({ success: false, message: 'titulo e video_url são obrigatórios' });

    if (typeof imagem_url === 'string' && imagem_url.startsWith('data:')) {
      const saved = saveDataUriToFile(imagem_url);
      if (saved.error) return res.status(400).json({ success: false, message: saved.error });
      imagem_url = saved.path;
    }

    if (typeof video_url === 'string' && video_url.startsWith('data:')) {
      return res.status(400).json({ success: false, message: 'Envio de vídeo em base64 não é suportado. Use link do YouTube.' });
    }

    if (typeof imagem_url === 'string' && imagem_url.length > 4000) {
      return res.status(400).json({ success: false, message: 'URL da imagem muito longa.' });
    }

    const result = await queryAsync(
      'INSERT INTO cursos (titulo, descricao, duracao, imagem_url, video_url) VALUES (?, ?, ?, ?, ?)',
      [titulo, descricao, duracao, imagem_url, video_url]
    );

    res.status(201).json({ success: true, message: 'Curso criado', id: result.insertId });
  } catch (err) {
    console.error('POST /admin/courses error:', err);
    res.status(500).json({ success: false, message: 'Erro ao criar curso', error: err.message });
  }
});

// listar usuarios (APENAS ADMIN)
app.get('/admin/users', isAdmin, async (req, res) => {
  try {
    const rows = await queryAsync('SELECT id, nome, email, tipo, criado_em FROM usuarios ORDER BY id DESC');
    res.json({ success: true, data: rows });
  } catch (err) {
    console.error('GET /admin/users error:', err);
    res.status(500).json({ success: false, message: 'Erro ao buscar usuários' });
  }
});

// change role (APENAS ADMIN)
app.put('/admin/users/:id/role', isAdmin, async (req, res) => {
  try {
    const id = parseInt(req.params.id, 10);
    const { tipo } = req.body;
    if (!id || !tipo || !['admin','usuario'].includes(tipo)) return res.status(400).json({ success:false, message:'Dados inválidos' });

    const result = await queryAsync('UPDATE usuarios SET tipo = ? WHERE id = ?', [tipo, id]);
    if (result.affectedRows === 0) return res.status(404).json({ success:false, message:'Usuário não encontrado.' });
    res.json({ success:true, message:'Role atualizado.' });
  } catch (err) {
    console.error('PUT /admin/users/:id/role error:', err);
    res.status(500).json({ success:false, message:'Erro ao atualizar role' });
  }
});

// deletar curso (APENAS ADMIN)
app.delete('/admin/courses/:id', isAdmin, async (req, res) => {
  try {
    const id = req.params.id;
    const result = await queryAsync('DELETE FROM cursos WHERE id = ?', [id]);
    if (result.affectedRows === 0) return res.status(404).json({ success: false, message: 'Curso não encontrado.' });
    res.json({ success: true, message: 'Curso deletado' });
  } catch (err) {
    console.error('DELETE /admin/courses/:id error:', err);
    res.status(500).json({ success: false, message: 'Erro ao deletar curso' });
  }
});

// deletar usuário (admin ou próprio usuário)
app.delete('/usuario/:id', async (req, res) => {
  try {
    const idParam = parseInt(req.params.id, 10);
    const requesterId = parseInt(req.headers['x-user-id'], 10);

    if (!requesterId) return res.status(401).json({ success: false, message: 'Usuário não autenticado.' });

    if (requesterId !== idParam) {
      const rows = await queryAsync('SELECT tipo FROM usuarios WHERE id = ?', [requesterId]);
      if (!rows || rows.length === 0) return res.status(401).json({ success: false, message: 'Usuário não encontrado.' });
      if (rows[0].tipo !== 'admin') return res.status(403).json({ success: false, message: 'Acesso negado.' });
    }

    const result = await queryAsync('DELETE FROM usuarios WHERE id = ?', [idParam]);
    if (result.affectedRows === 0) return res.status(404).json({ success: false, message: 'Usuário não encontrado.' });

    res.json({ success: true, message: 'Usuário deletado' });
  } catch (err) {
    console.error('DELETE /usuario/:id error:', err);
    res.status(500).json({ success: false, message: 'Erro ao deletar usuário.' });
  }
});

// cadastro
app.post('/usuario/cadastrar', async (req, res) => {
  try {
    const { nome, email, senha } = req.body;
    if (!nome || !email || !senha) return res.status(400).json({ success: false, message: 'Campos obrigatórios faltando.' });

    await queryAsync('INSERT INTO usuarios (nome, email, senha) VALUES (?, ?, ?)', [nome, email, senha]);
    res.status(201).json({ success: true, message: 'Usuário cadastrado com sucesso' });
  } catch (err) {
    console.error('POST /usuario/cadastrar error:', err);
    res.status(500).json({ success: false, message: 'Erro ao cadastrar usuário', error: err.message });
  }
});

// login (texto puro)
app.post('/usuario/login', async (req, res) => {
  try {
    const { email, senha } = req.body;
    if (!email || !senha) return res.status(400).json({ success: false, message: 'Email e senha obrigatórios' });

    const rows = await queryAsync('SELECT id, nome, email, senha, tipo FROM usuarios WHERE email = ?', [email]);
    if (!rows || rows.length === 0) return res.status(401).json({ success: false, message: 'E-mail ou senha incorretos!' });

    const user = rows[0];
    if (user.senha !== senha) return res.status(401).json({ success: false, message: 'Senha incorreta!' });

    res.json({ success: true, message: 'Login bem-sucedido!', username: user.nome, email: user.email, id: user.id, tipo: user.tipo });
  } catch (err) {
    console.error('POST /usuario/login error:', err);
    res.status(500).json({ success: false, message: 'Erro no servidor.' });
  }
});

app.listen(PORT, () => console.log(`Servidor rodando na porta ${PORT}`));
