// frontend/script.js
document.addEventListener('DOMContentLoaded', () => {

  // --- Lógica de Cadastro ---
  const registerForm = document.getElementById('registerForm');
  if (registerForm) {
    registerForm.addEventListener('submit', async (e) => {
      e.preventDefault();

      const nome = document.getElementById('regNome').value.trim();
      const email = document.getElementById('regEmail').value.trim();
      const senha = document.getElementById('regSenha').value;

      if (!nome || !email || !senha) {
        alert("Preencha todos os campos!");
        return;
      }

      try {
        const response = await fetch('http://localhost:3001/usuario/cadastrar', {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ nome, email, senha })
        });

        const result = await response.json();

        if (response.ok && result.success) {
          alert(result.message || 'Cadastrado com sucesso!');
          // redireciona para login
          window.location.href = 'login.html';
        } else {
          alert(result.message || 'Erro ao cadastrar');
        }
      } catch (error) {
        console.error('Erro durante o cadastro:', error);
        alert("Ocorreu um erro ao tentar realizar o cadastro.");
      }
    });
  }

  // --- Lógica de Login ---
  const loginForm = document.getElementById('loginForm');
  if (loginForm) {
    loginForm.addEventListener('submit', async (e) => {
      e.preventDefault();

      const email = document.getElementById('loginEmail').value.trim();
      const senha = document.getElementById('loginSenha').value;

      if (!email || !senha) {
        alert('Preencha todos os campos!');
        return;
      }

      try {
        const response = await fetch('http://localhost:3001/usuario/login', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ email, senha })
        });

        // tenta parsear o JSON (pode falhar se backend devolver HTML/erro)
        const result = await response.json();

        if (result.success) {
          // salva o usuário logado (id e tipo são importantes)
          localStorage.setItem('currentUser', JSON.stringify({
            username: result.username,
            email: result.email,
            id: result.id,
            tipo: result.tipo || 'usuario'
          }));

          alert('Login bem-sucedido!');

          // redireciona conforme tipo
          if (result.tipo === 'admin') {
            // se seu admin.html estiver na mesma pasta frontend
            window.location.href = 'admin.html';
          } else {
            window.location.href = 'dashboard.html';
          }
        } else {
          alert(result.message || 'Email ou senha incorretos.');
        }
      } catch (error) {
        console.error('Erro no login:', error);
        alert('Erro ao conectar ao servidor.');
      }
    });
  }

});



/// delete account - profile page
document.addEventListener('DOMContentLoaded', () => {
  const deleteBtn = document.getElementById('deleteAccount');
  if (deleteBtn) {
    deleteBtn.addEventListener('click', async () => {
      if (!confirm('Tem certeza que quer excluir sua conta? Essa ação é irreversível.')) return;
      const user = JSON.parse(localStorage.getItem('currentUser'));
      if (!user || !user.id) return alert('Usuário não autenticado.');

      try {
        const res = await fetch(`http://localhost:3001/usuario/${user.id}`, {
          method: 'DELETE',
          headers: {
            'Content-Type': 'application/json',
            'x-user-id': user.id // simples autenticação por dev
          }
        });
        const json = await res.json();
        if (json.success) {
          localStorage.removeItem('currentUser');
          alert('Conta excluída com sucesso.');
          window.location.href = '/frontend/index.html';
        } else {
          alert(json.message || 'Erro ao excluir conta.');
        }
      } catch (err) {
        console.error(err);
        alert('Erro ao conectar ao servidor.');
      }
    });
  }
});
